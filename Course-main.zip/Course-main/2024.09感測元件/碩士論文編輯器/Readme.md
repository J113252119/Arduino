<h2>Overleaf 線上編輯器</h2>

首先開啟網址: https://www.overleaf.com/  ，如下圖的註冊畫面，建議點選 "Sign up with Google" 進行註冊，<br>
帳號可以使用學生 Email : J113252XXX@nkust.edu.tw 註冊) <br>

>![](https://github.com/derricktsai0904/Course/blob/main/2024.09%E6%84%9F%E6%B8%AC%E5%85%83%E4%BB%B6/%E7%A2%A9%E5%A3%AB%E8%AB%96%E6%96%87%E7%B7%A8%E8%BC%AF%E5%99%A8/signup.jpg?raw=true)
