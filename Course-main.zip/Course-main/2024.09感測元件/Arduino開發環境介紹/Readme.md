
<b><font size=32>【Arduino 開發環境安裝】</font></b>

#### 1.下載Arduino ide Tool
##### 1.1 請到以下網址下載最新開發軟體，作業系統可建置在Mac OS、Linux、Windows 32位元及64位元
參考網址 : https://www.arduino.cc
>![](https://github.com/derricktsai0904/Arduino/blob/master/01.Arduino%E9%96%8B%E7%99%BC%E7%92%B0%E5%A2%83%E5%AE%89%E8%A3%9D/Arduino_Download.PNG?raw=true)
>![](https://github.com/derricktsai0904/Arduino/blob/master/01.Arduino%E9%96%8B%E7%99%BC%E7%92%B0%E5%A2%83%E5%AE%89%E8%A3%9D/Arduino_Download2.PNG?raw=true)
<hr>

##### 1.2 開發介面介紹
##### 1.2.1 Adruino IDE 介面

【基本按鈕】
>![](https://github.com/derricktsai0904/Arduino/blob/master/01.Arduino%E9%96%8B%E7%99%BC%E7%92%B0%E5%A2%83%E5%AE%89%E8%A3%9D/ArduinoInstall.PNG?raw=true)

【檢查裝置管理員是否有偵測到 Arduino開發板】
>![](https://github.com/derricktsai0904/Arduino/blob/master/01.Arduino%E9%96%8B%E7%99%BC%E7%92%B0%E5%A2%83%E5%AE%89%E8%A3%9D/ArduinoInstall1.PNG?raw=true)

【電腦接上 Arduino 開發板.USB連線方式】
>![](https://github.com/derricktsai0904/Arduino/blob/master/01.Arduino%E9%96%8B%E7%99%BC%E7%92%B0%E5%A2%83%E5%AE%89%E8%A3%9D/ArduinoInstall2.PNG?raw=true)

【設定使用開發板】
>![](https://github.com/derricktsai0904/Arduino/blob/master/01.Arduino%E9%96%8B%E7%99%BC%E7%92%B0%E5%A2%83%E5%AE%89%E8%A3%9D/ArduinoInstall3.PNG?raw=true)

【設定使用開發板連結埠】
>![](https://github.com/derricktsai0904/Arduino/blob/master/01.Arduino%E9%96%8B%E7%99%BC%E7%92%B0%E5%A2%83%E5%AE%89%E8%A3%9D/ArduinoInstall4.PNG?raw=true)

##### 1.3 Arduino開發板腳位說明
>![](https://github.com/derricktsai0904/Arduino/blob/master/01.Arduino%E9%96%8B%E7%99%BC%E7%92%B0%E5%A2%83%E5%AE%89%E8%A3%9D/ArduinoPoint.PNG?raw=true)

