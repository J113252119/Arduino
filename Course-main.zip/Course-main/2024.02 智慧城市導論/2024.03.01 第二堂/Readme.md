
Step 01. 登入 https://www.github.com ， 並且填寫一個 Email Address ，建議使用學校信箱。<br>
<img src="https://github.com/derricktsai0904/Course/blob/main/2024.02%20%E6%99%BA%E6%85%A7%E5%9F%8E%E5%B8%82%E5%B0%8E%E8%AB%96/2024.03.01%20%E7%AC%AC%E4%BA%8C%E5%A0%82/Step01.png" />

Step 02. 再次確認 Email信箱地址<br>
<img src="https://github.com/derricktsai0904/Course/blob/main/2024.02%20%E6%99%BA%E6%85%A7%E5%9F%8E%E5%B8%82%E5%B0%8E%E8%AB%96/2024.03.01%20%E7%AC%AC%E4%BA%8C%E5%A0%82/Step02.png" />

Step 03. 輸入一組密碼，建議是英數混合密碼<br>
<img src="https://github.com/derricktsai0904/Course/blob/main/2024.02%20%E6%99%BA%E6%85%A7%E5%9F%8E%E5%B8%82%E5%B0%8E%E8%AB%96/2024.03.01%20%E7%AC%AC%E4%BA%8C%E5%A0%82/Step03.png" />

Step 04. 輸入一組使用者名稱，建議填寫學號，必須要是唯一而且不與其他帳號相關，也是日後的 github 網址， https://www.github.com/xxxxxx      ( xxxxx 是你的使用者名稱 )<br>
<img src="https://github.com/derricktsai0904/Course/blob/main/2024.02%20%E6%99%BA%E6%85%A7%E5%9F%8E%E5%B8%82%E5%B0%8E%E8%AB%96/2024.03.01%20%E7%AC%AC%E4%BA%8C%E5%A0%82/Step04.png" />

Step 05. 勾選希望收到產品更新的通知<br>
<img src="https://github.com/derricktsai0904/Course/blob/main/2024.02%20%E6%99%BA%E6%85%A7%E5%9F%8E%E5%B8%82%E5%B0%8E%E8%AB%96/2024.03.01%20%E7%AC%AC%E4%BA%8C%E5%A0%82/Step05.png"/>

Step 06. 進行註冊的驗證<br>
<img src="https://github.com/derricktsai0904/Course/blob/main/2024.02%20%E6%99%BA%E6%85%A7%E5%9F%8E%E5%B8%82%E5%B0%8E%E8%AB%96/2024.03.01%20%E7%AC%AC%E4%BA%8C%E5%A0%82/Step06.png"/>

Step 07. 聽完播放的提示後，填寫答案。 (如果聽覺不方便，建議採用視覺驗證) <br>
<img src="https://github.com/derricktsai0904/Course/blob/main/2024.02%20%E6%99%BA%E6%85%A7%E5%9F%8E%E5%B8%82%E5%B0%8E%E8%AB%96/2024.03.01%20%E7%AC%AC%E4%BA%8C%E5%A0%82/Step07.png"/>

Step 08. 完成驗證後，就可以正式建立 github帳號 <br>
<img src="https://github.com/derricktsai0904/Course/blob/main/2024.02%20%E6%99%BA%E6%85%A7%E5%9F%8E%E5%B8%82%E5%B0%8E%E8%AB%96/2024.03.01%20%E7%AC%AC%E4%BA%8C%E5%A0%82/Step08.png"/>

Step 09. 系統提示要輸入驗證碼 (請到註冊填寫的 Email 收取 github 寄送的驗證碼 )<br>
<img src="https://github.com/derricktsai0904/Course/blob/main/2024.02%20%E6%99%BA%E6%85%A7%E5%9F%8E%E5%B8%82%E5%B0%8E%E8%AB%96/2024.03.01%20%E7%AC%AC%E4%BA%8C%E5%A0%82/Step09.png"/>

Step 10. 請到 Email 收取驗證碼，並填寫到剛剛的位置。<br>
<img src="https://github.com/derricktsai0904/Course/blob/main/2024.02%20%E6%99%BA%E6%85%A7%E5%9F%8E%E5%B8%82%E5%B0%8E%E8%AB%96/2024.03.01%20%E7%AC%AC%E4%BA%8C%E5%A0%82/Step10.png"/>
