

<img src="https://github.com/derricktsai0904/Course/blob/main/2024.02%20%E6%99%BA%E6%85%A7%E5%9F%8E%E5%B8%82%E5%B0%8E%E8%AB%96/Course.png" width="200" height="200">

課程名稱 : 智慧城市導論 <br>
任教老師 : 蔡正雄 ( 以及 江柏叡 教授)

|週次或項目 Week or Items	| 中文授課內容 Chinese Course Content | 英文授課內容 English Course Content	| 分配節次 Assigned Classes	| 備註 Note |
|------------------------:|------------------------------------|------------------------------------|---------------------------|----------|
|第一週 | 教學課程說明：課程內容簡介、考試方式、評分標準、其他注意事項 | Teaching course description: Introduction to course content, examination methods, scoring standards, and other matters needing attention | | | |
|第二週 |何謂智慧城市? | What is a smart city? | | | |
|第三週 |智慧城市的應用範圍 | Smart city scope  | | | |
|第四週 |IOT物聯網 | Internet of Things  | | | |
|第五週 |智慧防災 | Smart disaster prevention  | | | |
|第六週 |智慧交通 | Smart transportation  | | | |
|第七週 |智慧醫療 | Smart medical  | | | |
|第八週 |智慧農業 | Smart agriculture  | | | |
|第九週 |期中評量 |Mid-term evaluation  | | | |
|第十週 |智慧生活 |Smart life  | | | |
|第十一週 |智慧治理 |Smart governance  | | | |
|第十二週 |智慧教育 |Smart education  | | | |
|第十三週 |智慧安全 |Smart security  | | | |
|第十四週 |智慧能源 |Smart energy  | | | |
|第十五週 |期末報告(分組)|Final report (grouping)  | | | |
|第十六週 |期末報告(分組) |Final report (grouping)  | | | |
|第十七週 |期末報告(分組) |Final report (grouping)  | | | |
|第十八週 |期末評量 |Final evaluation  | | | |

