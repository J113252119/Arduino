|      履歷        |<img src="https://avatars.githubusercontent.com/u/22648375?v=4" width=100 height=100/>|
| ---------------- |:-----------------------------:|
| 姓名             | 蔡正雄                  |
| 學校             | 高雄科技大學                  |
| 電子郵件         | derrick@nkust.edu.tw          |
| 選修             | 智慧城市導論                  |
